/* *****************************************************************************
 *  Name:    Anurag Narayan
 *  NetID:   narayan
 *  Precept: P00
 *
 *  Description:  Programming assignment for coursera algs4 percolation
 *
 **************************************************************************** */


import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    // stores the percolation thresholds
    private double[] thresholds;

    // stores mean of percolation thresholds
    private double mean;

    // stores stddev of percolation thresholds
    private double stddev;

    // stores confidenceLow of percolation thresholds
    private double confidenceLow;

    // stores confidenceHigh of percolation thresholds
    private double confidenceHigh;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {

        thresholds = new double[trials];
        for (int trial = 0; trial < trials; trial++) {
            Percolation percolation = new Percolation(n);

            while (!percolation.percolates()) {
                int randomX = StdRandom.uniform(1, n+1);
                int randomY = StdRandom.uniform(1, n+1);
                percolation.open(randomX, randomY);
            }
            double threshold = percolation.numberOfOpenSites()/(double) (n * n);
            thresholds[trial] = threshold;
        }
        mean = StdStats.mean(thresholds);
        stddev =  StdStats.stddev(thresholds);
        confidenceLow = mean - ((1.96 * stddev)/Math.sqrt(trials));
        confidenceHigh = mean + ((1.96 * stddev)/Math.sqrt(trials));
    }

    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return stddev;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return confidenceLow;
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return confidenceHigh;
    }

    // test client (see below)
    public static void main(String[] args) {
        PercolationStats percolationStats = new PercolationStats(2, 100000);
        System.out.println("mean                    = " + percolationStats.mean());
        System.out.println("stddev                  = "+ percolationStats.stddev());
        System.out.println("95% confidence interval = [" + percolationStats.confidenceLo()
         + ", " + percolationStats.confidenceHi() + "]");
    }

}