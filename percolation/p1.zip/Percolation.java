/* *****************************************************************************
 *  Name:    Anurag Narayan
 *  NetID:   narayan
 *  Precept: P00
 *
 *  Description:  Programming assignment for coursera algs4 percolation
 *
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Percolation {
    // models the underlying grid
    private WeightedQuickUnionUF grid;

    // stores size of the grid
    private int size;

    // set to track opened sites
    private HashSet<Integer> openedSites;

    // first dummy site at index 0
    private int firstDummySite;

    // last dummy site at index size+1
    private int lastDummySite;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n - " + n + " should be greater than 0!");
        }
        size = n;
        grid = new WeightedQuickUnionUF(size * size + 2);
        openedSites = new HashSet<>();

        initializeDummySites();
    }

    // initializes dummy sites
    private void initializeDummySites() {
        // Open first dummy site
        firstDummySite = getSite(1, 1) - 1;
        openedSites.add(firstDummySite);

        // Link first row to first dummy site
        for (int i = 1; i <= size; i++) {
            grid.union(firstDummySite, i);
        }

        // Open last dummy site
        lastDummySite = getSite(size, size) + 1;
        openedSites.add(lastDummySite);

        // Link first row to first dummy site
        for (int i = (size*size - size) + 1; i <= size*size; i++) {
            grid.union(lastDummySite, i);
        }
    }


    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        validate(row, col);

        // connect the site to its adjacent open sites
        List<Integer> adjOpenSites = getAdjacentOpenSites(row, col);
        int site = getSite(row, col);

        for (int adjOpenSite : adjOpenSites) {
            grid.union(adjOpenSite, site);
        }
        openedSites.add(site);
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        validate(row, col);

        // check if the site is connected to at least one of its adjacent open sites
        List<Integer> adjSites = getAdjacentOpenSites(row, col);
        int site = getSite(row, col);
        for (int adjSite : adjSites) {
            if (grid.connected(adjSite, site)) {
                return true;
            }
        }
        return false;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        return !isOpen(row, col);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openedSites.size();
    }

    // does the system percolate?
    public boolean percolates() {
        return grid.connected(firstDummySite, lastDummySite);
    }

    // retrieves adjacent open sites
    private List<Integer> getAdjacentOpenSites(int row, int col) {
        List<Integer> adjOpenSites = new ArrayList<>();

        List<Integer> adjSites = getAdjacentSites(row, col);
        // int site = getSite(row, col);

        for (int adjSite : adjSites) {
            /* if (grid.connected(adjSite, site)) {
                adjOpenSites.add(adjSite);
            } */
            if (openedSites.contains(adjSite)) {
                adjOpenSites.add(adjSite);
            }
        }
        return adjOpenSites;
    }

    // retrieves adjacent sites
    private List<Integer> getAdjacentSites(int row, int col) {
        validate(row, col);
        List<Integer> adjacentSites = new ArrayList<>();
        // UP
        if (col - 1 >= 1) {
            adjacentSites.add(getSite(row, col - 1));
        }
        // DOWN
        if (col + 1 <= size) {
            adjacentSites.add(getSite(row, col + 1));
        }
        // LEFT
        if (row - 1 >= 1) {
            adjacentSites.add(getSite(row - 1, col));
        }
        // RIGHT
        if (row + 1 <= size) {
            adjacentSites.add(getSite(row + 1, col));
        }
        return adjacentSites;
    }

    // gets the underlying index corresponding to the grid cell
    private int getSite(int row, int col) {
        return ((col-1) * size + (row));
    }

    // validates
    private void validate(int row, int col) {
        if (row < 1 || row > size) {
            throw new IllegalArgumentException("row - " + row + " should be between 1 and " + size);
        }
        if (col < 1 || col > size) {
            throw new IllegalArgumentException("col - " + col + " should be between 1 and " + size);
        }
    }

    // test client (optional)
    public static void main(String[] args) {
        /*
        Percolation percolation = new Percolation(4);
        System.out.println("getAdjacentSites(1, 1) - " +
                                   percolation.getAdjacentSites(1, 1));
        System.out.println("getAdjacentSites(1, 4) - " +
                                   percolation.getAdjacentSites(1, 4));
        System.out.println("getAdjacentSites(4, 4) - " +
                                   percolation.getAdjacentSites(4, 4));
        System.out.println("getAdjacentSites(4, 1) - " +
                                   percolation.getAdjacentSites(4, 1));
        System.out.println("open(1,1)");
        percolation.open(1,1);
        System.out.println("isOpen(1, 1) - " + percolation.isOpen(1, 1));
        System.out.println("open(1,2)");
        percolation.open(1,2);
        System.out.println("isOpen(1, 1) - " + percolation.isOpen(1, 1));*/
    }
}